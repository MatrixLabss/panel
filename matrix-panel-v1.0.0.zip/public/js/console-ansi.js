// Shared console ANSI converter for view pages.
// Single source of truth for turning the server's ANSI/Minecraft-colored log
// lines into HTML (or ensuring lines carry ANSI for xterm). The palette matches
// the server-side terminal-color-parser and the xterm theme on the console page.
(function (global) {
    'use strict';

    const ESC = '\x1b';

    const BASE16 = [
        '#1a1a1a', '#ff5a5a', '#85ff85', '#ffc83c',
        '#5a9cff', '#ff85ff', '#5affff', '#e0e0e0',
        '#7a7a7a', '#ff7a7a', '#9dff9d', '#ffd86b',
        '#7ab5ff', '#ff9dff', '#7affff', '#ffffff'
    ];

    const LEVEL_COLORS = {
        error: '\x1b[38;2;255;90;90m',
        warn: '\x1b[38;2;255;200;60m',
        success: '\x1b[38;2;85;255;85m',
        system: '\x1b[38;2;120;180;255m',
        info: '\x1b[38;2;220;220;220m',
        debug: '\x1b[38;2;140;140;140m'
    };
    const RESET = '\x1b[0m';

    function escapeHtml(value) {
        return String(value).replace(/[&<>"']/g, ch => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        }[ch]));
    }

    function color256(n) {
        const v = Math.max(0, Math.min(255, Number(n) || 0));
        if (v < 16) return BASE16[v];
        if (v >= 232) {
            const g = 8 + (v - 232) * 10;
            return 'rgb(' + g + ',' + g + ',' + g + ')';
        }
        const i = v - 16;
        const r = Math.floor(i / 36), g = Math.floor((i % 36) / 6), b = i % 6;
        const level = x => x === 0 ? 0 : 55 + x * 40;
        return 'rgb(' + level(r) + ',' + level(g) + ',' + level(b) + ')';
    }

    function applySgr(state, codeText) {
        const parts = String(codeText || '0').split(';').map(v => parseInt(v, 10) || 0);
        for (let i = 0; i < parts.length; i++) {
            const p = parts[i];
            if (p === 0) {
                state.fg = state.bg = null;
                state.bold = state.dim = state.italic = state.underline = false;
            } else if (p === 1) state.bold = true;
            else if (p === 2) state.dim = true;
            else if (p === 3) state.italic = true;
            else if (p === 4) state.underline = true;
            else if (p === 22) { state.bold = false; state.dim = false; }
            else if (p === 23) state.italic = false;
            else if (p === 24) state.underline = false;
            else if (p >= 30 && p <= 37) state.fg = BASE16[p - 30];
            else if (p >= 90 && p <= 97) state.fg = BASE16[p - 90 + 8];
            else if (p === 39) state.fg = null;
            else if (p >= 40 && p <= 47) state.bg = BASE16[p - 40];
            else if (p >= 100 && p <= 107) state.bg = BASE16[p - 100 + 8];
            else if (p === 49) state.bg = null;
            else if (p === 38 || p === 48) {
                const isFg = p === 38;
                const mode = parts[i + 1];
                if (mode === 2) {
                    const color = 'rgb(' + (parts[i + 2] || 0) + ',' + (parts[i + 3] || 0) + ',' + (parts[i + 4] || 0) + ')';
                    if (isFg) state.fg = color; else state.bg = color;
                    i += 4;
                } else if (mode === 5) {
                    const color = color256(parts[i + 2]);
                    if (isFg) state.fg = color; else state.bg = color;
                    i += 2;
                }
            }
        }
    }

    // Convert ESC SGR sequences into HTML spans. HTML special chars are
    // escaped first, so untrusted log content can never inject markup.
    function ansiToHtml(raw) {
        if (raw == null) return '';
        const text = String(raw);
        const re = /\x1b\[([0-9;]*)m/g;
        const state = { fg: null, bg: null, bold: false, dim: false, italic: false, underline: false };
        let out = '';
        let lastIndex = 0;
        let spanOpen = false;

        const closeSpan = () => {
            if (spanOpen) { out += '</span>'; spanOpen = false; }
        };
        const openSpan = () => {
            const css = [];
            if (state.fg) css.push('color:' + state.fg);
            if (state.bg) css.push('background-color:' + state.bg);
            if (state.bold) css.push('font-weight:bold');
            if (state.dim) css.push('opacity:0.65');
            if (state.italic) css.push('font-style:italic');
            if (state.underline) css.push('text-decoration:underline');
            if (css.length) { out += '<span style="' + css.join(';') + '">'; spanOpen = true; }
        };

        let match;
        while ((match = re.exec(text)) !== null) {
            if (match.index > lastIndex) {
                openSpan();
                out += escapeHtml(text.slice(lastIndex, match.index));
                closeSpan();
            }
            applySgr(state, match[1]);
            lastIndex = re.lastIndex;
        }
        if (lastIndex < text.length) {
            openSpan();
            out += escapeHtml(text.slice(lastIndex));
            closeSpan();
        }
        return out;
    }

    // Strip ANSI, literal "[38;2;...m" text and Minecraft section codes so
    // level detection sees plain text only.
    function stripAnsi(raw) {
        if (raw == null) return '';
        return String(raw)
            .replace(/\x1b\[[0-9;?]*[A-Za-z]/g, '')
            .replace(/\[[0-9]{1,3}(?:;[0-9]{1,3})*m/g, '')
            .replace(/§x(?:§[0-9a-fA-F]){6}/g, '')
            .replace(/§#[0-9a-fA-F]{6}/g, '')
            .replace(/§[0-9a-fk-or]/gi, '');
    }

    // Same rules as the server-side terminal-color-parser so the CSS level
    // class always matches the color the server already applied.
    function detectLevel(raw) {
        if (!raw) return 'info';
        const upper = stripAnsi(raw).toUpperCase();
        if (upper.includes('ERROR') || upper.includes('FATAL') || upper.includes('EXCEPTION')) return 'error';
        if (upper.includes('WARN')) return 'warn';
        if (upper.includes('DEBUG') || upper.includes('TRACE')) return 'debug';
        if (upper.includes('DONE') || upper.includes('LOADED') || upper.includes('SUCCESS')) return 'success';
        return 'info';
    }

    // Convert literal "[38;2;255;85;85m" text (ESC missing) into real ANSI.
    function normalizeLiteralAnsi(text) {
        return String(text).replace(
            /(^|[^\x1b])\[([0-9]{1,3}(?:;[0-9]{1,3})*)m/g,
            (match, prefix, codes) => prefix + ESC + '[' + codes + 'm'
        );
    }

    // Ensure a line carries ANSI so xterm/HTML never shows plain white;
    // lines that already have ANSI are passed through untouched.
    function ensureAnsi(message, level) {
        const text = normalizeLiteralAnsi(message);
        if (text.includes(ESC + '[')) return text;
        return (LEVEL_COLORS[level] || LEVEL_COLORS.info) + text + RESET;
    }

    // Build a console line element with ANSI colors rendered into HTML.
    function buildLine(raw, forcedLevel) {
        const div = document.createElement('div');
        const level = forcedLevel || detectLevel(raw);
        div.className = 'srv-console-line log-' + level;
        try {
            div.innerHTML = ansiToHtml(raw);
        } catch (e) {
            div.textContent = stripAnsi(raw);
        }
        return div;
    }

    global.ConsoleAnsi = {
        BASE16,
        LEVEL_COLORS,
        color256,
        ansiToHtml,
        stripAnsi,
        detectLevel,
        normalizeLiteralAnsi,
        ensureAnsi,
        buildLine
    };
})(window);
