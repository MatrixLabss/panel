/**
 * Node Management Utilities
 * Helper functions for node operations, validation, and communication
 */

const crypto = require('crypto');
const https = require('https');
const http = require('http');

class NodeUtilities {
  constructor(db) {
    this.db = db;
  }

  // ================================================
  // TOKEN & SECURITY UTILITIES
  // ================================================

  /**
   * Generate a secure random token for node authentication
   */
  static generateToken(length = 64) {
    return crypto.randomBytes(length / 2).toString('hex');
  }

  /**
   * Hash a token using SHA-256
   */
  static hashToken(token) {
    return crypto.createHash('sha256').update(token).digest('hex');
  }

  /**
   * Verify token against hash
   */
  static verifyToken(token, hash) {
    return this.hashToken(token) === hash;
  }

  // ================================================
  // NODE VALIDATION
  // ================================================

  /**
   * Validate IP address format
   */
  static isValidIP(ip) {
    const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
    const ipv6Regex = /^([\da-f]{0,4}:){2,7}[\da-f]{0,4}$/i;
    const hostnameRegex = /^([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)*[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/i;

    if (ipv4Regex.test(ip)) {
      const parts = ip.split('.');
      return parts.every(part => parseInt(part) <= 255);
    }

    return ipv6Regex.test(ip) || hostnameRegex.test(ip);
  }

  /**
   * Validate port number
   */
  static isValidPort(port) {
    return port > 0 && port < 65536 && Number.isInteger(port);
  }

  /**
   * Validate port range
   */
  static isValidPortRange(start, end) {
    return (
      this.isValidPort(start) &&
      this.isValidPort(end) &&
      start < end &&
      end - start >= 10
    );
  }

  /**
   * Validate node configuration
   */
  static validateNodeConfig(config) {
    const errors = [];

    if (!config.name || typeof config.name !== 'string' || config.name.trim() === '') {
      errors.push('Node name is required');
    }

    if (!config.ip_address || !this.isValidIP(config.ip_address)) {
      errors.push('Valid IP address or hostname is required');
    }

    if (!config.daemon_port || !this.isValidPort(config.daemon_port)) {
      errors.push('Valid daemon port is required (1-65535)');
    }

    if (config.ram_mb < 128 || config.ram_mb > 1048576) {
      errors.push('RAM must be between 128 MB and 1 TB');
    }

    if (config.cpu_cores < 0.1 || config.cpu_cores > 4096) {
      errors.push('CPU cores must be between 0.1 and 4096');
    }

    if (config.disk_mb < 256 || config.disk_mb > 104857600) {
      errors.push('Disk must be between 256 MB and 100 TB');
    }

    if (config.port_ranges && Array.isArray(config.port_ranges)) {
      for (const range of config.port_ranges) {
        if (!this.isValidPortRange(range.start, range.end)) {
          errors.push(`Invalid port range: ${range.start}-${range.end}`);
        }
      }
    }

    return { valid: errors.length === 0, errors };
  }

  // ================================================
  // DAEMON COMMUNICATION
  // ================================================

  /**
   * Send HTTPS request to daemon
   */
  static async sendToDaemon(nodeIp, daemonPort, method, path, data = null, token = null) {
    return new Promise((resolve, reject) => {
      const isHttps = true; // Assume HTTPS for security
      const protocol = isHttps ? https : http;

      const options = {
        hostname: nodeIp,
        port: daemonPort,
        path: path,
        method: method,
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'Minecraft-Panel/1.0'
        },
        rejectUnauthorized: false // In production, validate certificates properly
      };

      if (token) {
        options.headers['X-Daemon-Token'] = token;
      }

      let body = '';

      const req = protocol.request(options, (res) => {
        res.on('data', (chunk) => {
          body += chunk;
        });

        res.on('end', () => {
          try {
            const response = JSON.parse(body);
            if (res.statusCode >= 400) {
              reject(new Error(response.error || `HTTP ${res.statusCode}`));
            } else {
              resolve(response);
            }
          } catch (err) {
            reject(new Error(`Invalid JSON response: ${body}`));
          }
        });
      });

      req.on('error', (err) => {
        reject(new Error(`Daemon communication error: ${err.message}`));
      });

      req.setTimeout(10000, () => {
        req.destroy();
        reject(new Error('Daemon request timeout'));
      });

      if (data) {
        req.write(JSON.stringify(data));
      }

      req.end();
    });
  }

  /**
   * Check node health by sending heartbeat
   */
  async checkNodeHealth(db, nodeId) {
    return new Promise((resolve) => {
      db.get(
        `SELECT * FROM nodes WHERE id = ?`,
        [nodeId],
        async (err, node) => {
          if (err || !node) {
            resolve({ healthy: false, error: 'Node not found' });
            return;
          }

          try {
            const result = await NodeUtilities.sendToDaemon(
              node.ip_address,
              node.daemon_port,
              'POST',
              '/heartbeat',
              {},
              node.daemon_token
            );

            // Update last heartbeat
            db.run(
              `UPDATE nodes SET last_heartbeat = CURRENT_TIMESTAMP, status = 'online' WHERE id = ?`,
              [nodeId],
              (err) => {
                if (!err) {
                  // Store resource data
                  if (result.resources) {
                    const memPercent = (result.resources.memory.used / result.resources.memory.total) * 100;
                    db.run(
                      `INSERT INTO node_resources (node_id, memory_used_mb, memory_total_mb, cpu_usage_percent, timestamp)
                       VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)`,
                      [
                        nodeId,
                        Math.round(result.resources.memory.used / 1024 / 1024),
                        Math.round(result.resources.memory.total / 1024 / 1024),
                        result.resources.cpu?.usage || 0
                      ]
                    );
                  }
                }
              }
            );

            resolve({ healthy: true, data: result });
          } catch (err) {
            // Mark node as offline
            db.run(
              `UPDATE nodes SET status = 'offline' WHERE id = ?`,
              [nodeId]
            );
            resolve({ healthy: false, error: err.message });
          }
        }
      );
    });
  }

  // ================================================
  // PORT ALLOCATION UTILITIES
  // ================================================

  /**
   * Get available ports for a node
   */
  async getAvailablePorts(nodeId, count = 1) {
    return new Promise((resolve, reject) => {
      this.db.all(
        `SELECT port FROM port_allocations WHERE node_id = ? AND assigned = 0 LIMIT ?`,
        [nodeId, count],
        (err, ports) => {
          if (err) reject(err);
          else resolve(ports?.map(p => p.port) || []);
        }
      );
    });
  }

  /**
   * Check if port is available on node
   */
  async isPortAvailable(nodeId, port) {
    return new Promise((resolve, reject) => {
      this.db.get(
        `SELECT id FROM port_allocations WHERE node_id = ? AND port = ? AND assigned = 0`,
        [nodeId, port],
        (err, row) => {
          if (err) reject(err);
          else resolve(!!row);
        }
      );
    });
  }

  /**
   * Allocate port to server
   */
  async allocatePort(nodeId, serverId, port) {
    return new Promise((resolve, reject) => {
      this.db.run(
        `UPDATE port_allocations SET assigned = 1, server_id = ? WHERE node_id = ? AND port = ?`,
        [serverId, nodeId, port],
        (err) => {
          if (err) reject(err);
          else resolve(true);
        }
      );
    });
  }

  /**
   * Deallocate port from server
   */
  async deallocatePort(nodeId, port) {
    return new Promise((resolve, reject) => {
      this.db.run(
        `UPDATE port_allocations SET assigned = 0, server_id = NULL WHERE node_id = ? AND port = ?`,
        [nodeId, port],
        (err) => {
          if (err) reject(err);
          else resolve(true);
        }
      );
    });
  }

  /**
   * Get all available ports in a node's port ranges
   */
  async initializeNodePorts(nodeId, portRanges) {
    return new Promise((resolve, reject) => {
      const allocations = [];

      for (const range of portRanges) {
        for (let port = range.start; port <= range.end; port++) {
          allocations.push(port);
        }
      }

      // Batch insert
      const placeholders = allocations.map(() => '(?, ?)').join(',');
      const values = allocations.flatMap(port => [nodeId, port]);

      this.db.run(
        `INSERT INTO port_allocations (node_id, port) VALUES ${placeholders}`,
        values,
        (err) => {
          if (err) reject(err);
          else resolve(allocations.length);
        }
      );
    });
  }

  // ================================================
  // NODE STATE MANAGEMENT
  // ================================================

  /**
   * Get node statistics
   */
  async getNodeStats(nodeId) {
    return new Promise((resolve, reject) => {
      this.db.get(
        `SELECT * FROM node_resources WHERE node_id = ? ORDER BY timestamp DESC LIMIT 1`,
        [nodeId],
        (err, stats) => {
          if (err) reject(err);
          else resolve(stats);
        }
      );
    });
  }

  /**
   * Get node resource history
   */
  async getNodeResourceHistory(nodeId, hours = 24) {
    return new Promise((resolve, reject) => {
      this.db.all(
        `SELECT * FROM node_resources 
         WHERE node_id = ? AND timestamp > datetime('now', '-' || ? || ' hours')
         ORDER BY timestamp DESC`,
        [nodeId, hours],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows || []);
        }
      );
    });
  }

  /**
   * Log node action
   */
  async logNodeAction(nodeId, userId, action, description, status = 'success', details = {}, ipAddress = null) {
    return new Promise((resolve, reject) => {
      this.db.run(
        `INSERT INTO node_logs (node_id, user_id, action, description, status, details, ip_address)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [nodeId, userId || null, action, description, status, JSON.stringify(details), ipAddress],
        (err) => {
          if (err) reject(err);
          else resolve(true);
        }
      );
    });
  }
}

module.exports = NodeUtilities;
